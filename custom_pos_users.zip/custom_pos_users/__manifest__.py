{
    'name': 'Custom POS Shop Restriction',
    'depends': ['base', 'point_of_sale', 'contacts'],
    'data': [
        # 'security\pos_security.xml'
        
        'views/custom_res_partners.xml'
             ],
    'installable': True,
    'application': False,
}